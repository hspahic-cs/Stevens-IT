# jspin
GUI for running the SPIN model checker

Moti Ben-Ari

The GUI enables running the SPIN model checker without knowing the command-line arguments. Most options are easily accessible from menus and shortcuts. The output is formatted to facilitate understanding the results of a simulation or verification.
